package com.phonebooksearch.test;

import junit.framework.JUnit4TestAdapter;
import junit.framework.TestCase;

import org.junit.Test;

import com.phonebooksearch.service.PhoneBookService;
// PhoneBookSearchTest is tested
// assert statements
public class PhoneBookSearchTest extends TestCase {

	private PhoneBookService phoneBookService;
	
    @Override
    protected void setUp() throws Exception {
        super.setUp();
        this.phoneBookService = new PhoneBookService();
        phoneBookService.loadPhoneBookAsList("c:\\PhoneBook\\phoneBook_20.csv");
        phoneBookService.loadPhoneBookAsMap("c:\\PhoneBook\\phoneBook_20.csv");
    }
		
	@Test
	public void testSetupComplete() {
		assertNotNull("phoneBookService is not initialized", phoneBookService);
	}
  
	@Test
	public void testPhoneBookLoadedAsList() {
		assertNotNull("PhoneBookEntriesList is null", phoneBookService.getPhoneBookEntriesList());
		assertNotNull("NamesInPBEntriesList is null", phoneBookService.getNamesInPBEntriesList());
		
		assertTrue("PhoneBookEntriesList is of zero size", (phoneBookService.getPhoneBookEntriesList().size() > 0));
		assertTrue("NamesInPBEntriesList is of zero size", (phoneBookService.getNamesInPBEntriesList().size() > 0));
		
		//System.out.print(phoneBookService.getPhoneBookEntriesList().size() + ", " + phoneBookService.getNamesInPBEntriesList().size());
		
		assertTrue("PhoneBookEntriesList and NamesInPBEntriesList are not of same size", 
				(phoneBookService.getPhoneBookEntriesList().size() == phoneBookService.getNamesInPBEntriesList().size()));
	}
	
	@Test
	public void testPhoneBooksearchFromList() {
		assertTrue("Invalid search results for Full Name from List", (phoneBookService.searchPhoneBookByFullNameUsingList("Donato Kling").size() == 2));
		assertTrue("Invalid search results for Partial Name from List", (phoneBookService.searchPhoneBookByFullNameUsingList("Donato").size() == 0));
		assertTrue("Invalid search results for Non Existing Name from List", (phoneBookService.searchPhoneBookByFullNameUsingList("XYZ").size() == 0));
	}

	@Test
	public void testPhoneBooksearchFromMap() {
		assertTrue("Invalid search results for Full Name from Full Map Search", (phoneBookService.searchPhoneBookByFullNameUsingMap("Donato Kling").size() == 2));
		assertTrue("Invalid search results for Partial Name from Full Map Search", (phoneBookService.searchPhoneBookByFullNameUsingMap("Donato").size() == 0));
		assertTrue("Invalid search results for Non Existing Name from Full Map Search", (phoneBookService.searchPhoneBookByFullNameUsingMap("XYZ").size() == 0));
		
		assertTrue("Invalid search results for Full Name from Pattern Map Search", (phoneBookService.searchPhoneBookByPartialNameUsingMap("Donato Kling").size() == 3));
		assertTrue("Invalid search results for Partial Name from Pattern Map Search", (phoneBookService.searchPhoneBookByPartialNameUsingMap("Donato").size() == 3));
		assertTrue("Invalid search results for Non Existing from Pattern Map Search", (phoneBookService.searchPhoneBookByPartialNameUsingMap("XYZ").size() == 0));
	}
	
	@Test
	public void testPhoneBookLoadedAsMap() {
		assertNotNull("phoneBookSortedMap is null", phoneBookService.getPhoneBookSortedMap());		
		assertTrue("getPhoneBookSortedMap is of zero size", (phoneBookService.getPhoneBookSortedMap().size() > 0));
	}	
	
	private int multiply(int i, int y) {
		return i * y;
	}
  
	@Test
	public void multiplicationOfZeroIntegersShouldReturnZero() {

		//PhoneBookSearchTest is tested
		PhoneBookSearchTest tester = new PhoneBookSearchTest();

		//assert statements
		assertEquals("10 x 0 must be 0", 0, tester.multiply(10, 0));
		assertEquals("0 x 10 must be 0", 0, tester.multiply(0, 10));
		assertEquals("0 x 0 must be 0", 0, tester.multiply(0, 0));
	}

	public static junit.framework.Test suite(){
		return new JUnit4TestAdapter(PhoneBookSearchTest.class);
	}
} 
