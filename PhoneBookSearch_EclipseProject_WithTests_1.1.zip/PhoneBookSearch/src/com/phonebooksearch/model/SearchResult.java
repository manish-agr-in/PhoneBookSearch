package com.phonebooksearch.model;

public class SearchResult {
	
	private String searchResult;

	public String getSearchResult() {
		return searchResult;
	}

	public void setSearchResult(String searchResult) {
		this.searchResult = searchResult;
	}
	
	public SearchResult(String searchResult){
		this.searchResult = searchResult;
	}
}
