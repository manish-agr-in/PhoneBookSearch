package com.phonebooksearch.model;

import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class PhoneBookEntries implements Iterable, Comparator {
	
	private String name;
	private List<PhoneBookEntry> phoneBookEntryList;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<PhoneBookEntry> getPhoneBookEntryList() {
		return phoneBookEntryList;
	}

	public void setPhoneBookEntryList(List<PhoneBookEntry> phoneBookEntryList) {
		this.phoneBookEntryList = phoneBookEntryList;
	}

	public PhoneBookEntries(String name, List<PhoneBookEntry> phoneBookEntryList){
		this.name = name;
		this.phoneBookEntryList = phoneBookEntryList;
	}
	
	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Iterator iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime
				* result
				+ ((phoneBookEntryList == null) ? 0 : phoneBookEntryList
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PhoneBookEntries other = (PhoneBookEntries) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (phoneBookEntryList == null) {
			if (other.phoneBookEntryList != null)
				return false;
		} else if (!phoneBookEntryList.equals(other.phoneBookEntryList))
			return false;
		return true;
	}
	
}
