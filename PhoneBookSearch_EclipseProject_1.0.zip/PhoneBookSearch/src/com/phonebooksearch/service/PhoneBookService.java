package com.phonebooksearch.service;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.phonebooksearch.model.PhoneBookEntries;
import com.phonebooksearch.model.PhoneBookEntry;
import com.phonebooksearch.model.SearchResult;

public class PhoneBookService {
	
	private String phoneBookFile;
	
	private Map<String, List<PhoneBookEntry>> phoneBookSortedMap = new TreeMap<String, List<PhoneBookEntry>>();
	
	private List<PhoneBookEntries> phoneBookEntriesList = null;
	private List<String> namesInPBEntriesList = null;
	
	public Map<String, List<PhoneBookEntry>> getPhoneBook() {
		return phoneBookSortedMap;
	}

	//Loads the Phone Book on Application Startup (Loads both Map & List forms) 
	public void init(){
		long startTime = System.currentTimeMillis();
		
		loadPhoneBookAsMap(phoneBookFile);
		long endTime = System.currentTimeMillis();
		System.out.println("\nPopulated Phonebook Map with : "
				+ phoneBookSortedMap.size()
				+ " records, time taken to load in seconds: "
				+ (endTime - startTime) / 1000.0);
		
		startTime = System.currentTimeMillis();
		
		loadPhoneBookAsList(phoneBookFile);
		endTime = System.currentTimeMillis();
		System.out.println("\nPopulated Phonebook List with : "
				+ namesInPBEntriesList.size()
				+ " records, time taken to load in seconds: "
				+ (endTime - startTime) / 1000.0);		
	}
    
	//Performs search on loaded List using a separately cached name array
	//Through Binary Search on the name array, the index can be found for corresponding list for same index  
	public List<SearchResult> searchPhoneBookByFullNameUsingList(String searchStr){
		
		long startTime = System.currentTimeMillis();

		String mapKey = searchStr.trim().toUpperCase(); //Map keys (names) were initially stored with Upper Case
				
		int indexOfSearchTerm = binarySearch(namesInPBEntriesList, 0, 
				namesInPBEntriesList.size()-1, mapKey);
		
		List<SearchResult> resultsList = new ArrayList<SearchResult>();
		StringBuilder sb = new StringBuilder();
		
		if(indexOfSearchTerm < 0){
			return resultsList;
			
		} else {
			PhoneBookEntries phoneBookEntries = phoneBookEntriesList.get(indexOfSearchTerm);
			for(PhoneBookEntry phoneBookEntry :  phoneBookEntries.getPhoneBookEntryList()){
				sb.append(mapKey).append(" - ");
				for(String phoneNumber : phoneBookEntry.getPhoneNumbers() ){
					sb.append(phoneNumber).append(", ");
				}
				if(sb.toString().trim().endsWith(",")){
					sb.deleteCharAt(sb.length()-2);	
				}
				resultsList.add(new SearchResult(sb.toString().trim()));
				sb.delete(0, sb.length());  
			}
		}

		long endTime = System.currentTimeMillis();
		System.out.println("\nTime taken in searching '" + searchStr
				+ "' for Full Name Search using List in "
				+ namesInPBEntriesList.size() + " records: "
				+ (endTime - startTime) / 1000.0);
		
		return resultsList;
		
	}//searchPhoneBookByFullNameUsingList
	
	//Recursive Binary Search on name array
    private int binarySearch(List<String> list, int firstElem, int lastElem, String searchTextinUpperCase) {
        
    	if (firstElem < lastElem) {  
    		
            int middle = firstElem + (lastElem - firstElem) / 2;
            if (searchTextinUpperCase.compareTo(list.get(middle)) < 0) {
                return binarySearch(list, firstElem, middle, searchTextinUpperCase);
 
            } else if (searchTextinUpperCase.compareTo(list.get(middle)) > 0) {
                return binarySearch(list, middle+1, lastElem, searchTextinUpperCase);
 
            } else {
                return middle;
            }
        }
        return -1;
    }//binarySearch	
	
    //Loads Phone Book as List using custom sorting algorithm (Called from init)
	private void loadPhoneBookAsList(String fileName){
		
		if( phoneBookSortedMap == null || phoneBookSortedMap.size() <= 0){
			loadPhoneBookAsMap(fileName);
		}
		
		Map<String, PhoneBookEntries> phoneBookMap = new TreeMap<String, PhoneBookEntries>();
		
        String line = null;
        String key = null;
        String[] lineArray = null;
        String[] phoneNoArray = null;
        
        List<String> phoneNumbers = null;
        PhoneBookEntries phoneBookEntries = null;
        List<PhoneBookEntry> phoneBookEntryList = null;
        PhoneBookEntry phoneBookEntry = null;

        try {
            //FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            //Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);
			
            while((line = bufferedReader.readLine()) != null) {
                
            	lineArray = line.trim().split("\\s*,\\s*"); //Splits and removes spaces
            	key = lineArray[0];
            	key = key.trim().toUpperCase();
            	phoneNoArray = Arrays.copyOfRange(lineArray, 1, lineArray.length);            	
            	phoneNumbers = Arrays.asList(phoneNoArray);
            	phoneBookEntry = new PhoneBookEntry(phoneNumbers);
            	
            	if( phoneBookMap.containsKey(key) ){
            		phoneBookEntries = (PhoneBookEntries) phoneBookMap.get(key);
            		phoneBookEntryList = phoneBookEntries.getPhoneBookEntryList();
            		phoneBookEntryList.add(phoneBookEntry);
            		phoneBookEntries.setPhoneBookEntryList(phoneBookEntryList);
            		phoneBookMap.put(key, phoneBookEntries);
            		
            	} else {
            		phoneBookEntryList = new ArrayList<PhoneBookEntry>();
            		phoneBookEntryList.add(phoneBookEntry);
            		phoneBookEntries = new PhoneBookEntries(key, phoneBookEntryList);
            		phoneBookMap.put(key, phoneBookEntries);
            	}
            	
            	key = null;
            	lineArray = null;
            	phoneNoArray = null;
            	phoneNumbers = null;
            	phoneBookEntries = null;
            	phoneBookEntryList = null;
            	phoneBookEntry = null;
            	            	
            }
            
            phoneBookEntriesList = new ArrayList<PhoneBookEntries>();
            
            for(Map.Entry<String, PhoneBookEntries> entry : phoneBookMap.entrySet()){
            	phoneBookEntriesList.add(entry.getValue());
            }
            
            Collections.sort(phoneBookEntriesList, NameComparator);//TODO - Custom sorting algorithm which populates namesArray as well.
            
            namesInPBEntriesList = new ArrayList<String>();
            
            //Populate namesInPBEntriesList which will be used to search by index from phoneBookEntriesList (Will have same index)
            for(PhoneBookEntries pbEntries : phoneBookEntriesList){
            	namesInPBEntriesList.add(pbEntries.getName()); 
            } 
                        
            //Close bufferedReader
            bufferedReader.close();
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }			
	}//loadPhoneBookAsList    

	//Comparator for List sorting while loading
    public static final Comparator<PhoneBookEntries> NameComparator = new Comparator<PhoneBookEntries>(){
        @Override
        public int compare(PhoneBookEntries o1, PhoneBookEntries o2) {
            return o1.getName().compareTo(o2.getName());
        }
    };	

    //Performs a partial name search on Phone Book in Map. Map is iterated and search string is searched in each Map Key with case ignored. 
    //All results with matching partial string are returned. 
    public List<SearchResult> searchPhoneBookByPartialNameUsingMap(String searchStr){
		
		long startTime = System.currentTimeMillis();
		
		List<SearchResult> resultsList = new ArrayList<SearchResult>();
		StringBuilder sb = new StringBuilder();

		for (String mapKey : phoneBookSortedMap.keySet()) {
    		if(mapKey.toUpperCase().contains(searchStr.toUpperCase())){
    			for(PhoneBookEntry phoneBookEntry : (List<PhoneBookEntry>)phoneBookSortedMap.get(mapKey) ){
    				sb.append(mapKey).append(" - ");
        			for(String phoneNumber : phoneBookEntry.getPhoneNumbers() ){
        				sb.append(phoneNumber).append(", ");
        			}
        			if(sb.toString().trim().endsWith(",")){
        				sb.deleteCharAt(sb.length()-2);	
        			}
        			resultsList.add(new SearchResult(sb.toString().trim()));
        			sb.delete(0, sb.length());  
    			}
    		}
		}
		long endTime = System.currentTimeMillis();
		System.out.println("\nTime taken in searching '" + searchStr
				+ "' for Partial Name Search using Map in " 
				+ phoneBookSortedMap.size() + " records: "
				+ (endTime - startTime) / 1000.0);
		
		return resultsList;
		
	}//searchPhoneBookByPartialNameUsingMap
	
    //Performs a full name search on Phone Book loaded as Red-Black tree based SortedMap.
    public List<SearchResult> searchPhoneBookByFullNameUsingMap(String searchStr){
		
		long startTime = System.currentTimeMillis();
		
		String mapKey = searchStr.trim().toUpperCase(); //Map keys (names) were initially stored with Upper Case
		
		List<SearchResult> resultsList = new ArrayList<SearchResult>();
		StringBuilder sb = new StringBuilder();
		
		List<PhoneBookEntry> phoneBookEntryList = (List<PhoneBookEntry>)phoneBookSortedMap.get(mapKey);
		
		if( phoneBookEntryList != null && phoneBookEntryList.size() > 0){
			for(PhoneBookEntry phoneBookEntry :  phoneBookEntryList){
				sb.append(mapKey).append(" - ");
				for(String phoneNumber : phoneBookEntry.getPhoneNumbers() ){
					sb.append(phoneNumber).append(", ");
				}
				if(sb.toString().trim().endsWith(",")){
					sb.deleteCharAt(sb.length()-2);	
				}
				resultsList.add(new SearchResult(sb.toString().trim()));
				sb.delete(0, sb.length());  
			}
		}
		
		long endTime = System.currentTimeMillis();
		System.out.println("\nTime taken in searching '" + searchStr
				+ "' for Full Name Search using Map in "
				+ phoneBookSortedMap.size() + " records: "
				+ (endTime - startTime) / 1000.0);
		
		return resultsList;
		
	}//searchPhoneBookByFullNameUsingMap	
	
    //Loads Phone Book as Map (Called from init)    
	private void loadPhoneBookAsMap(String fileName){
		
		Map<String, List<PhoneBookEntry>> phoneBookMap = new HashMap<String, List<PhoneBookEntry>>();
		
        String line = null;
        String key = null;
        String[] lineArray = null;
        String[] phoneNoArray = null;
        
        List<String> phoneNumbers = null;
        List<PhoneBookEntry> phoneBookEntryList = null;
        PhoneBookEntry phoneBookEntry = null;

        try {
            //FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            //Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);
			
            while((line = bufferedReader.readLine()) != null) {
                
            	lineArray = line.trim().split("\\s*,\\s*"); //Splits and removes spaces
            	key = lineArray[0];
            	key = key.trim().toUpperCase();
            	phoneNoArray = Arrays.copyOfRange(lineArray, 1, lineArray.length);            	
            	phoneNumbers = Arrays.asList(phoneNoArray);
            	phoneBookEntry = new PhoneBookEntry(phoneNumbers);
            	
            	if( phoneBookMap.containsKey(key) ){
            		phoneBookEntryList = phoneBookMap.get(key);
            		phoneBookEntryList.add(phoneBookEntry);
            		phoneBookMap.put(key, phoneBookEntryList);
            		
            	} else {
            		phoneBookEntryList = new ArrayList<PhoneBookEntry>();
            		phoneBookEntryList.add(phoneBookEntry);
            		phoneBookMap.put(key, phoneBookEntryList);
            	}
            	
            	key = null;
            	lineArray = null;
            	phoneNoArray = null;
            	phoneNumbers = null;
            	phoneBookEntryList = null;
            	phoneBookEntry = null;
            }
            
            phoneBookSortedMap = new TreeMap<String, List<PhoneBookEntry>>(phoneBookMap);
                        
            //Close bufferedReader
            bufferedReader.close();
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }			
	}//loadPhoneBookAsMap
	
	public String getPhoneBookFile() {
		return phoneBookFile;
	}

	public void setPhoneBookFile(String phoneBookFile) {
		this.phoneBookFile = phoneBookFile;
	}

	public void destroy(){
		phoneBookFile = null;
		phoneBookSortedMap = null;
		phoneBookEntriesList = null;
		namesInPBEntriesList = null;		
	}

}//PhoneBookService
