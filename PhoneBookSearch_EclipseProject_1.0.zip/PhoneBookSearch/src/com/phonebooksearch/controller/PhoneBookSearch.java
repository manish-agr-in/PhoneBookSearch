package com.phonebooksearch.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.phonebooksearch.model.SearchResult;
import com.phonebooksearch.service.PhoneBookService;

@Controller
public class PhoneBookSearch {
	
	@Autowired
	private PhoneBookService phoneBookService;
	
	@RequestMapping("/search")
	public ModelAndView helloWorld() {//Method called when the Application is loaded
		ModelAndView mav = new ModelAndView("search");
		return mav;
	}
	
	@RequestMapping(value = "/doSearchUsingMap", method = RequestMethod.POST)
	public ModelAndView partialNameSearch(@RequestParam("searchText") String searchText)
			throws Exception {//Method invoked when search is performed for Java TreeMap which is a Red-Black tree based implementation 

		//List<SearchResult> searchResultsList = phoneBookService.searchPhoneBookByPartialNameUsingMap(searchText);
		List<SearchResult> searchResultsList = phoneBookService.searchPhoneBookByFullNameUsingMap(searchText);

		ModelAndView mav = new ModelAndView("searchResults");
		mav.addObject("searchResults", searchResultsList);
		return mav;
	}
	
	@RequestMapping(value = "/doSearchUsingList", method = RequestMethod.POST)
	public ModelAndView fullNameSearch(@RequestParam("searchText") String searchText)
			throws Exception {//Method invoked when search is performed for Java List. A custom sorting and searching algorithm has been provided for it.

		List<SearchResult> searchResultsList = phoneBookService.searchPhoneBookByFullNameUsingList(searchText); //TODO - Change to List

		ModelAndView mav = new ModelAndView("searchResults");
		mav.addObject("searchResults", searchResultsList);
		return mav;
	}	
}